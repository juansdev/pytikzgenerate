# Este archivo es importado de __init__.py y ejecutado desde setup.py

MAJOR = 0
MINOR = 2
MICRO = 2
RELEASE = False

__version__ = '%d.%d.%d' % (MAJOR, MINOR, MICRO)